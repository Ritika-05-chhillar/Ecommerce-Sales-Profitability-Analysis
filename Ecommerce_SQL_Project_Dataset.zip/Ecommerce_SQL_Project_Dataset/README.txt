# E-commerce Sales & Profitability Analysis — Practice Dataset

## Dataset type
Synthetic company-style dataset created for portfolio practice. It is not real customer or company data.

## Files
- customers.csv: customer profile, city, state, segment and signup date
- products.csv: product category, selling price and unit cost
- orders.csv: order date, status, payment method and sales channel
- order_items.csv: products and quantities within each order, with discount

## Suggested analysis
1. Revenue and order performance
2. Product and category profitability
3. Regional performance
4. Customer segmentation and repeat purchases
5. Monthly trends and order status analysis

## Data-quality practice
The dataset intentionally includes a few quality issues (duplicate customer row, blank email values, and invalid zero quantities) for cleaning exercises. Document how you identify and handle them.

## Important
All records are synthetic and generated for educational/portfolio use.
